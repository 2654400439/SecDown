# SecDown supplementary material — LaTeX source

This source builds the standalone supplementary report for **Silent Surrender: Measuring MitM-Induced TLS Downgrades in LLM Agents**, accepted at NDSS 2027.

Version: 1.0, October 28, 2026.

## Build

Use XeLaTeX and BibTeX. With Python 3 and a working TeX installation:

```sh
python build.py
```

The resulting file is `SecDown-Supplementary-Material.pdf` in this directory. Intermediate files are written to `build/`.

In Overleaf, select `supplement.tex` as the main document and XeLaTeX as the compiler. The included `supplement.bbl` is a bibliography snapshot; `references.bib` remains the editable source.

Times New Roman and Consolas are used when available. The source falls back to TeX Gyre Termes and Latin Modern Mono. Recheck pagination when compiling with different fonts.

## Organization

- `sections/`: ten topic-based sections, numbered S1–S10.
- `tables/`: task inventory and detailed experimental tables.
- `figures/`: source panels for prompts and execution cases, plus two original PDF figures.
- `authors.tex`: author names, affiliations, and contact information.
- `frontmatter.tex`: title, version, paper DOI, and reading guide.

The report's section, table, figure, listing, and reference numbering is independent of the conference paper. Its prompt scaffolds preserve the documented wording and explanatory annotations; execution cases preserve the original excerpts and redactions.

Project: https://github.com/2654400439/SecDown

Conference paper DOI: https://doi.org/10.14722/ndss.2027.230944
