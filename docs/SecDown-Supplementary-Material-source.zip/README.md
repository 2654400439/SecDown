# SecDown supplementary material — LaTeX source

This source builds the standalone supplementary report for **Silent Surrender: Measuring MitM-Induced TLS Downgrades in LLM Agents**, accepted at NDSS 2027.

Version: 2.0, October 29, 2026. The report uses the same IEEEtran two-column layout as the conference paper, with a separate supplementary title and independent numbering.

## Build

Use XeLaTeX and BibTeX. With Python 3 and a working TeX installation:

```sh
python build.py
```

The resulting file is `SecDown-Supplementary-Material.pdf` in this directory. Intermediate files are written to `build/`.

In Overleaf, select `supplement.tex` as the main document and XeLaTeX as the compiler. The included `supplement.bbl` is a bibliography snapshot; `references.bib` remains the editable source.

Times New Roman is used when available, with TeX Gyre Termes as the fallback and the TeX installation's monospace font for code. Recheck pagination when compiling with different fonts. The final reference page uses `\IEEEtriggeratref{75}` to balance its columns; revisit this value if references or pagination change.

## Organization

- `sections/`: a study overview followed by ten topic-based sections, numbered S1–S11.
- `tables/`: task inventory and detailed experimental tables.
- `figures/`: source panels for prompts and execution cases, plus two original PDF figures.
- `authors.tex`: author names, affiliations, and contact information.
- `frontmatter.tex`: title, abstract, version, paper DOI, and repository link.
- `IEEEtran.cls`, `IEEEtran.bst`: the class and bibliography style used for the report.

The report's section, table, figure, listing, and reference numbering is independent of the conference paper. Its prompt scaffolds preserve the documented wording and explanatory annotations; execution cases preserve the original excerpts and redactions. Tables and figures retain the original manuscript's single-column or full-width placement style. New introductory explanations clarify the threat setting, denominators, failure profiles, and how to read the templates and comparisons.

Project: https://github.com/2654400439/SecDown

Conference paper DOI: https://doi.org/10.14722/ndss.2027.230944
