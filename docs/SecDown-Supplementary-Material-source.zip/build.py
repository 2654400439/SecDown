"""Build the standalone supplemental report using XeLaTeX and BibTeX."""
from pathlib import Path
import shutil
import subprocess
import sys

root = Path(__file__).resolve().parent
build = root / 'build'
build.mkdir(exist_ok=True)
xelatex = ['xelatex', '-disable-installer', '-interaction=nonstopmode',
           '-halt-on-error', '-file-line-error', '-output-directory=build', 'supplement.tex']
commands = [xelatex, ['bibtex', 'build/supplement'], xelatex, xelatex]
for i, cmd in enumerate(commands, 1):
    print(f'Pass {i}: {cmd[0]}', flush=True)
    p = subprocess.run(cmd, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       encoding='utf-8', errors='replace')
    (build / f'pass_{i}.txt').write_text(p.stdout, encoding='utf-8')
    if p.returncode:
        print('\n'.join(p.stdout.splitlines()[-40:]))
        sys.exit(p.returncode)
for i in range(2):
    log = (build / 'supplement.log').read_text(encoding='utf-8', errors='replace')
    if 'Label(s) may have changed' not in log and 'Rerun to get' not in log:
        break
    p = subprocess.run(xelatex, cwd=root, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                       encoding='utf-8', errors='replace')
    (build / f'pass_{i+5}.txt').write_text(p.stdout, encoding='utf-8')
    if p.returncode:
        print(p.stdout[-4000:])
        sys.exit(p.returncode)
log = (build / 'supplement.log').read_text(encoding='utf-8', errors='replace')
for line in log.splitlines():
    if any(t in line for t in ['Overfull','undefined','multiply defined','Missing character','Float too large','Output written']):
        print(line)
destination = root / 'SecDown-Supplementary-Material.pdf'
shutil.copy2(build / 'supplement.pdf', destination)
shutil.copy2(build / 'supplement.bbl', root / 'supplement.bbl')
print('PDF:', destination)
